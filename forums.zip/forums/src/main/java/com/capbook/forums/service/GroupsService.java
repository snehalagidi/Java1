package com.capbook.forums.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capbook.forums.dao.IGroupsDao;
import com.capbook.forums.model.FriendsList;

@Service("groupService")
public class GroupsService implements IGroupsService {
	
	@Autowired
	private IGroupsDao groupsDao;

	@Override
	public List<FriendsList> findFriends() {
		List<FriendsList> list =groupsDao.findAll();
		return list;
	}

	@Override
	public List<FriendsList> exitFriends(Integer id) {
		
		 groupsDao.deleteById(id);
		 
		 return groupsDao.findAll();
	}

}
