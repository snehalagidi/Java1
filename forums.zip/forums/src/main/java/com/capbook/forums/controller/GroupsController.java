package com.capbook.forums.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.capbook.forums.model.FriendsList;
import com.capbook.forums.service.IGroupsService;

@RestController
@CrossOrigin("http://localhost:4200")
public class GroupsController {

	
	
	
	@Autowired
	private IGroupsService groupService;
	

	@GetMapping("/findall")
	public ResponseEntity<List<FriendsList>> findFriends(){
		List<FriendsList> friendsList=groupService.findFriends();
		return new ResponseEntity<List<FriendsList>>(friendsList, HttpStatus.OK);
	}
	
	@DeleteMapping("/exitUser/{id}")
	public ResponseEntity<List<FriendsList>> exitFriends(@PathVariable("id")Integer id){
		List<FriendsList> friends= groupService.exitFriends(id);
		if(friends.isEmpty() || friends==null) {
			return new ResponseEntity("Sorry! ProductsId not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<FriendsList>>(friends, HttpStatus.OK);
		
	}

	/*@DeleteMapping("/products/{productId}")
	public ResponseEntity<List<Product>> deleteProduct(
			@PathVariable("productId")Integer productId){
		List<Product> products= productService.deleteProduct(productId);
		if(products.isEmpty() || products==null) {
			return new ResponseEntity("Sorry! ProductsId not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}*/
	
}
