package com.capbook.forums.service;

import java.util.List;

import com.capbook.forums.model.FriendsList;

public interface IGroupsService {

	List<FriendsList> findFriends();

	List<FriendsList> exitFriends(Integer id);

	

}
