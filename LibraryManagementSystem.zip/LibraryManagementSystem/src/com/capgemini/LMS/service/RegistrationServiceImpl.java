package com.capgemini.LMS.service;

import java.util.List;

import com.capgemini.LMS.DAO.IRegistrationDao;
import com.capgemini.LMS.DAO.RegistrationDaoImpl;
import com.capgemini.LMS.bean.BooksInventoryBean;
import com.capgemini.LMS.bean.BooksRegistrationBean;
import com.capgemini.LMS.bean.UsersBean;
import com.capgemini.LMS.exception.LibraryException;

public class RegistrationServiceImpl implements IRegistrationService{

	
	IRegistrationDao regdao = new RegistrationDaoImpl();
	@Override
	public List<BooksRegistrationBean> getRegistration(UsersBean usersBean, BooksInventoryBean booksInventory) throws LibraryException {

		return regdao.getRegistration(usersBean, booksInventory);
	}

	@Override
	public void doRegistration(BooksInventoryBean booksInventory, UsersBean usersBean, BooksRegistrationBean booksRegistration) throws LibraryException {
		regdao.doRegistration(booksInventory, usersBean, booksRegistration);
		
	}

}
