package com.capgemini.LMS.service;

import java.util.List;

import com.capgemini.LMS.DAO.AddDeleteBookDaoImpl;
import com.capgemini.LMS.DAO.IAddDeleteBookDao;
import com.capgemini.LMS.bean.BooksInventoryBean;
import com.capgemini.LMS.exception.LibraryException;


public class AddDeleteBookServiceImpl implements IAddDeleteBookService {
	
	 IAddDeleteBookDao addDelete= new AddDeleteBookDaoImpl();

	@Override
	public void addBook(BooksInventoryBean booksInventory) throws LibraryException {
		addDelete.addBook(booksInventory);
		
	}

	@Override
	public List<BooksInventoryBean> getAllBooks() throws LibraryException {
		return addDelete.getAllBooks();
	}

	@Override
	public void deleteBook(String bookId) throws LibraryException {

		addDelete.deleteBook(bookId);
		
	}

	

}
