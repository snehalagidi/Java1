package com.capgemini.LMS.service;

import java.util.List;

import com.capgemini.LMS.bean.BooksInventoryBean;
import com.capgemini.LMS.bean.BooksRegistrationBean;
import com.capgemini.LMS.bean.UsersBean;
import com.capgemini.LMS.exception.LibraryException;

public interface IRegistrationService {
	
	public List<BooksRegistrationBean> getRegistration(UsersBean usersBean , BooksInventoryBean booksInventory)throws LibraryException;
	public void doRegistration(BooksInventoryBean booksInventory, UsersBean usersBean, BooksRegistrationBean booksRegistration)throws LibraryException;

}
