package com.capgemini.LMS.service;

import java.util.List;

import com.capgemini.LMS.bean.BooksRegistrationBean;
import com.capgemini.LMS.bean.BooksTransactionBean;
import com.capgemini.LMS.exception.LibraryException;

public interface ITransactionService {

	public void doTransaction(BooksTransactionBean booksTransaction, BooksRegistrationBean booksRegistration)throws LibraryException;
	//public List<BooksTransactionBean> getAllTransaction(BooksRegistrationBean booksRegistration)throws LibraryException;	
}
