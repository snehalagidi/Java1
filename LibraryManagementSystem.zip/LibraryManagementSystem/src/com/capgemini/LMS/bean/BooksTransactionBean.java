package com.capgemini.LMS.bean;

import java.time.LocalDate;

public class BooksTransactionBean {

	private String transactionId;
	private BooksRegistrationBean registrationId;
	private LocalDate issueDate;
	
	public BooksTransactionBean() {
		
	}
	public BooksTransactionBean(String transactionId, BooksRegistrationBean registrationId, LocalDate issueDate) {
		super();
		this.transactionId = transactionId;
		this.registrationId = registrationId;
		this.issueDate = issueDate;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public BooksRegistrationBean getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(BooksRegistrationBean registrationId) {
		this.registrationId = registrationId;
	}
	public LocalDate getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}
	
	@Override
	public String toString() {
		return "BooksTransaction [transactionId=" + transactionId
				+ ", registrationId=" + registrationId + ", issueDate="
				+ issueDate + "]";
	}	
	
}
