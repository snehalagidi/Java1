package com.capgemini.LMS.bean;

import java.time.LocalDate;

public class BooksRegistrationBean {

	private String registrationId;
	private BooksInventoryBean bookId;
	private UsersBean userId;
	private LocalDate registrationDate;

	public BooksRegistrationBean() {

	}
	public BooksRegistrationBean(String registrationId, BooksInventoryBean bookId, UsersBean userId, LocalDate registrationDate) {
		super();
		this.registrationId = registrationId;
		this.bookId = bookId;
		this.userId = userId;
		this.registrationDate = registrationDate;
	}
	
	public String getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(String registrationId) {
		this.registrationId = registrationId;
	}
	public BooksInventoryBean getBookId() {
		return bookId;
	}
	public void setBookId(BooksInventoryBean bookId) {
		this.bookId = bookId;
	}
	public UsersBean getUserId() {
		return userId;
	}
	public void setUserId(UsersBean userId) {
		this.userId = userId;
	}
	public LocalDate getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}
	@Override
	public String toString() {
		return "BooksRegistration [registrationId=" + registrationId + ", bookId=" + bookId + ", userId=" + userId
				+ ", registrationDate=" + registrationDate + "]";
	}


}
