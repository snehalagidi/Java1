package com.capgemini.LMS.exception;

public class LibraryException extends Exception {
	private static final long serialVersionUID = 6738870095413400728L;
	private String message;
	
	public LibraryException() {
		
	}

	public LibraryException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "LibraryException [message=" + message + "]";
	}
	
}
