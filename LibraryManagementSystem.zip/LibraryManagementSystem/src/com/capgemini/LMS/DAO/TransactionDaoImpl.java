package com.capgemini.LMS.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.LMS.bean.BooksRegistrationBean;
import com.capgemini.LMS.bean.BooksTransactionBean;
import com.capgemini.LMS.exception.LibraryException;
import com.capgemini.LMS.util.DBConnection;

public class TransactionDaoImpl implements ITransactionDao{
	private static Logger daoLogger=Logger.getLogger(TransactionDaoImpl.class);
	@Override
	public void doTransaction(BooksTransactionBean booksTransaction, BooksRegistrationBean booksRegistration) throws LibraryException {
		
				
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();)
		{
			PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.INSERT_BOOK_TRANSACTION);
			preparedStatement.setString(1, booksTransaction.getTransactionId());
			preparedStatement.setString(2, booksRegistration.getRegistrationId());
			preparedStatement.setDate(3, java.sql.Date.valueOf(booksTransaction.getIssueDate()));
			int row=preparedStatement.executeUpdate();
			if(row>0)
				System.out.println("The Book has been issued to the student");			
		} catch (SQLException e) {
			daoLogger.error(e);
			throw new LibraryException("Technical error refer logs");

		}			
	}
}
