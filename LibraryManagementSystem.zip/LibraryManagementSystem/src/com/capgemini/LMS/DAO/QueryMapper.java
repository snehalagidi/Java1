package com.capgemini.LMS.DAO;

public class QueryMapper {

	public static final String DISPLAY_USERS="select * from users";
	
	public static final String INSERT_BOOK_INVENTORY="insert into BooksInventory values(?,?,?,?,?,?)";
	public static final String DISPLAY_BOOKS_INVENTORY="select * from BooksInventory";
	public static final String DELETE_FROM_BOOK_INVENTORY="delete from booksinventory where book_id = ?";
	
	public static final String INSERT_BOOK_REGISTRATION="insert into BooksRegistration values(?,?,?,?)";
	public static final String DISPLAY_BOOK_REGISTRATION="select * from BooksRegistration";
	public static final String CHECK_USER_ID="select * from BooksRegistration where user_id=?";
	
	public static final String INSERT_BOOK_TRANSACTION="insert into BooksTransaction  (transaction_id, registration_id, issue_date) values(?,?,?)";
	public static final String DISPLAY_BOOK_TRANSACTION="select * from BooksTransaction";
	
	public static final String DELETE_BOOK_FOREIGN_KEY_CHECK1="SET foreign_key_checks = 0";
	public static final String DELETE_BOOK_FOREIGN_KEY_CHECK2="SET foreign_key_checks = 1";
	
}
