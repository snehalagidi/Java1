package com.capgemini.LMS.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.LMS.bean.BooksInventoryBean;
import com.capgemini.LMS.exception.LibraryException;
import com.capgemini.LMS.util.DBConnection;


public class AddDeleteBookDaoImpl implements IAddDeleteBookDao {
	private static Logger daoLogger=Logger.getLogger(AddDeleteBookDaoImpl.class);
	@Override
	public void addBook(BooksInventoryBean booksInventory) throws LibraryException {	

		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();)
				{
			PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.INSERT_BOOK_INVENTORY);
			preparedStatement.setString(1, booksInventory.getBookId());
			preparedStatement.setString(2, booksInventory.getBookName());
			preparedStatement.setString(3, booksInventory.getAuthor1());
			preparedStatement.setString(4, booksInventory.getAuthor2());
			preparedStatement.setString(5, booksInventory.getPublisher());
			preparedStatement.setString(6, booksInventory.getYearOfPub());

			int row=preparedStatement.executeUpdate();

			if(row>0)
				System.out.println("Book has been added to the library!");

				} catch (SQLException e) {
					daoLogger.error(e);
					throw new LibraryException("Technical error refer logs");

				}			

	}

	@Override
	public List<BooksInventoryBean> getAllBooks() throws LibraryException {

		List<BooksInventoryBean> allBookList = new ArrayList<>();

		try(
				Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
			)
			{
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.DISPLAY_BOOKS_INVENTORY);
				ResultSet resultSet= preparedStatement.executeQuery();
			
				while(resultSet.next()){
				BooksInventoryBean booksInventory = new BooksInventoryBean();
				booksInventory.setBookId(resultSet.getString(1));
				booksInventory.setBookName(resultSet.getString(2));
				booksInventory.setAuthor1(resultSet.getString(3));
				booksInventory.setAuthor2(resultSet.getString(4));
				booksInventory.setPublisher(resultSet.getString(5));
				booksInventory.setYearOfPub(resultSet.getString(6));
				allBookList.add(booksInventory);
				}
				
			}catch (SQLException e){
				daoLogger.error(e);
				throw new LibraryException("Technical error refer logs");

			}
		return allBookList;

	}


	public void deleteBook(String bookId) throws LibraryException {
		
		try(
				Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				){
			PreparedStatement preparedStatement1=connection.prepareStatement(QueryMapper.DELETE_BOOK_FOREIGN_KEY_CHECK1);
			preparedStatement1.executeQuery();
			PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.DELETE_FROM_BOOK_INVENTORY);
			preparedStatement.setString(1, bookId);
			int row = preparedStatement.executeUpdate();

			if(row<0)
			{
				System.out.println("Book has not been deleted");
			}
			else
			{
				System.out.println("Book has  been deleted");
			}


			PreparedStatement preparedStatement2=connection.prepareStatement(QueryMapper.DELETE_BOOK_FOREIGN_KEY_CHECK2);
			preparedStatement2.executeQuery();

		} catch (SQLException e) {
			daoLogger.error(e);
			throw new LibraryException("Technical error refer logs");

		}



	}

}
