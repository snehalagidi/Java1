package com.capgemini.LMS.DAO;

import java.util.List;

import com.capgemini.LMS.bean.BooksInventoryBean;
import com.capgemini.LMS.bean.BooksRegistrationBean;
import com.capgemini.LMS.bean.UsersBean;
import com.capgemini.LMS.exception.LibraryException;


public interface IRegistrationDao {
	
	public List<BooksRegistrationBean> getRegistration(UsersBean user, BooksInventoryBean books)throws LibraryException;
	void doRegistration(BooksInventoryBean books, UsersBean user, BooksRegistrationBean register)throws LibraryException;

}
