package com.capgemini.LMS.DAO;

import java.util.List;

import com.capgemini.LMS.bean.BooksRegistrationBean;
import com.capgemini.LMS.bean.BooksTransactionBean;
import com.capgemini.LMS.exception.LibraryException;

public interface ITransactionDao {
	
	public void doTransaction(BooksTransactionBean bookstransaction, BooksRegistrationBean regid)throws LibraryException;
	//public List<BooksTransactionBean> getAllTransaction(BooksRegistrationBean regid)throws LibraryException;	
}
