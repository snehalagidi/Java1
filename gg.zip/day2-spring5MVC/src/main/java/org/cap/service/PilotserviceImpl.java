package org.cap.service;

import java.util.List;

import org.cap.dao.IPilotDao;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("pilotService")
public class PilotserviceImpl implements IPilotService{
	
	@Autowired
	private IPilotDao pilotDao;

	@Override
	public void savePilot(Pilot pilot) {
		pilotDao.savePilot(pilot);
		
	}

	@Override
	public List<Pilot> getPilotDetails() {
		
		return pilotDao.getPilotDetails();
	}

	@Override
	public void deletePilot(Integer pilotId) {
		// TODO Auto-generated method stub
		pilotDao.deletePilot(pilotId);
		
	}
	

}
