package com.capgemini.CapBook.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.CapBook.Dao.IMsgDao;
import com.capgemini.CapBook.model.Message;

@Service("msgService")
public class MsgServiceImpl implements IMsgService {
	@Autowired
	private IMsgDao msgdao;
	
	@Autowired
	private IMsgDao inventorydao;

	@Override
	public List<Message> getAllMessages() {
		
		return msgdao.findAll();
	}

	@Override
	public List<Message> saveMessage(Message msg) {
		
		msgdao.save(msg);
		return msgdao.findAll();
	}

}
