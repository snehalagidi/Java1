package com.capgemini.CapBook.model;




import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="SMS")
public class Message {

	@Id
	@GeneratedValue
	private int msgId;
	private String msgBody;
	private Date ReceivedDate;
	private int userId;
	private String toMobileNumber;
	
	
	
	public Message() {
		super();
	}
	
	
	public Message(int msgId, String msgBody, Date receivedDate, int userId, String toMobileNumber) {
		super();
		this.msgId = msgId;
		this.msgBody = msgBody;
		ReceivedDate = receivedDate;
		this.userId = userId;
		this.toMobileNumber = toMobileNumber;
	}
	
	public int getMsgId() {
		return msgId;
	}
	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}
	public String getMsgBody() {
		return msgBody;
	}
	public void setMsgBody(String msgBody) {
		this.msgBody = msgBody;
	}
	public Date getReceivedDate() {
		return ReceivedDate;
	}
	public void setReceivedDate(Date receivedDate) {
		ReceivedDate = receivedDate;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getToMobileNumber() {
		return toMobileNumber;
	}
	public void setToMobileNumber(String toMobileNumber) {
		this.toMobileNumber = toMobileNumber;
	}
	@Override
	public String toString() {
		return "Message [msgId=" + msgId + ", msgBody=" + msgBody + ", ReceivedDate=" + ReceivedDate + ", userId="
				+ userId + ", toMobileNumber=" + toMobileNumber + "]";
	}
	
	
}
