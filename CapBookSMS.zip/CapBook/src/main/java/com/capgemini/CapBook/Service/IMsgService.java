package com.capgemini.CapBook.Service;

import java.util.List;

import com.capgemini.CapBook.model.Message;



public interface IMsgService {

	public List<Message> getAllMessages();
	public List<Message> saveMessage(Message msg);
}
