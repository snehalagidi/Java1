package com.capgemini.CapBook.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.CapBook.Service.IMsgService;
import com.capgemini.CapBook.model.Message;

@RestController
@RequestMapping("/api")
public class MsgController {

	@Autowired
	private IMsgService msgService;
	
	@GetMapping("/msg")
	public ResponseEntity<List<Message>> getAllMessages(){
		
		List<Message> messages=msgService.getAllMessages();
		if(messages.isEmpty())

			return new ResponseEntity("Sorry! No Messages",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Message>>(messages, HttpStatus.OK); 
		}
	
	@PostMapping("/msg")
public ResponseEntity<List<Message>> saveMessages(@RequestBody Message msg){
		
		List<Message> messages=msgService.saveMessage(msg);
		if(messages.isEmpty())

			return new ResponseEntity("Sorry! No Messages",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Message>>(messages, HttpStatus.OK); 
		}
	
	
}
