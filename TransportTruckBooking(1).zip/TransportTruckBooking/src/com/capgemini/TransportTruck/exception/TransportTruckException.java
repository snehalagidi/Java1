package com.capgemini.TransportTruck.exception;

public class TransportTruckException extends Exception{
	
	private static final long serialVersionUID = 1L;
	private String message;

	public TransportTruckException() {
		super();
	}

	public TransportTruckException(String message) {
		super();
		this.message = message;
	}
	
	

	@Override
	public String toString() {
		return "TransportTruckException [message=" + message + "]";
	}

	public String getMessage() {
		return message;
	}

}
