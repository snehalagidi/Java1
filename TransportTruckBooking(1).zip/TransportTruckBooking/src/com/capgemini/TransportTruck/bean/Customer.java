package com.capgemini.TransportTruck.bean;

public class Customer {

}
