package com.capbook.forums.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capbook.forums.dao.IUserProfileDao;
import com.capbook.forums.model.UserProfile;

@Service("userService")
public class UserService implements IUserService {

	@Autowired
	private IUserProfileDao userProfileDao;

	@Override
	public UserProfile findGroupsuser(Integer input) {
	
		return userProfileDao.findByUserId(input);
	}
}
