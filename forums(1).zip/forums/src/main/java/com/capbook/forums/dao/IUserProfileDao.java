package com.capbook.forums.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capbook.forums.model.UserProfile;


@Repository("userProfileDao")
@Transactional
public interface IUserProfileDao extends JpaRepository<UserProfile, Integer>{
	
	UserProfile findByUserId(Integer input);

}
