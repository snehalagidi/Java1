package com.capbook.forums.dao;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capbook.forums.model.Group_Request;


@Repository("requestDao")
@Transactional

public interface IRequestDao extends JpaRepository<Group_Request, Integer>{
	

}

