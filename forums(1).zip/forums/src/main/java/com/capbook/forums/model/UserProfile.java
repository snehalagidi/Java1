package com.capbook.forums.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserProfile {

	@Id
	private Integer userId;
	private String userName;
	
	
	
	public UserProfile() {
		super();
	}



	public UserProfile(Integer userId, String userName) {
		super();
		this.userId = userId;
		this.userName = userName;
	}



	public Integer getUserId() {
		return userId;
	}



	public void setUserId(Integer userId) {
		this.userId = userId;
	}



	public String getUserName() {
		return userName;
	}



	public void setUserName(String userName) {
		this.userName = userName;
	}



	@Override
	public String toString() {
		return "UserProfile [userId=" + userId + ", userName=" + userName + "]";
	}
	
	
}
