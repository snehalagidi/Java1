package com.capbook.forums.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capbook.forums.model.FriendsList;
import com.capbook.forums.model.Group_Comments;
import com.capbook.forums.model.Group_Topic;
@Repository("commentDao")
@Transactional
public interface IGroupCommentDao extends JpaRepository<Group_Comments, Integer> {

}
