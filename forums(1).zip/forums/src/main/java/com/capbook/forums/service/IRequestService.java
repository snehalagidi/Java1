package com.capbook.forums.service;

import java.util.List;

import com.capbook.forums.model.Group_Request;

public interface IRequestService {
	List<Group_Request> requestSent(Group_Request request);

	List<Group_Request> findRequest();

}
