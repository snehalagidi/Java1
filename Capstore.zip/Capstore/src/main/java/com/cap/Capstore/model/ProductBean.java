package com.cap.Capstore.model;


import java.io.Serializable;
import java.sql.Date;
import java.util.Arrays;

import javax.validation.constraints.Future;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonFormat;


public class ProductBean implements Serializable{

	
	
	private Integer productId;
	@NotEmpty(message="*please enter Product Name.")

	private String productName;
	private String Description;
	@Future(message="* Please nter future date.")
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date ExpiryDate;
	private Integer Quantity;
	private Double Price;
	private String Category;
	private byte[] Image;
	
	public ProductBean() {
		
	}
	public ProductBean(Integer productId, String productName, String description, Date expiryDate, Integer quantity,
			Double price, String category, byte[] image) {
		super();
		this.productId = productId;
		this.productName = productName;
		Description = description;
		ExpiryDate = expiryDate;
		Quantity = quantity;
		Price = price;
		Category = category;
		Image = image;
	}

	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Date getExpiryDate() {
		return ExpiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		ExpiryDate = expiryDate;
	}
	public Integer getQuantity() {
		return Quantity;
	}
	public void setQuantity(Integer quantity) {
		Quantity = quantity;
	}
	public Double getPrice() {
		return Price;
	}
	public void setPrice(Double price) {
		Price = price;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public byte[] getImage() {
		return Image;
	}
	public void setImage(byte[] image) {
		Image = image;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", Description=" + Description
				+ ", ExpiryDate=" + ExpiryDate + ", Quantity=" + Quantity + ", Price=" + Price + ", Category="
				+ Category + ", Image=" + Arrays.toString(Image) + "]";
	}
	
}