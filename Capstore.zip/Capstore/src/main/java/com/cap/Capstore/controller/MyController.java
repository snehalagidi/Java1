package com.cap.Capstore.controller;

import java.util.HashMap;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.cap.Capstore.model.ProductBean;

@Controller
public class MyController { 
	
	
	private 
	 ProductBean product=new ProductBean();
	@RequestMapping("/")
	public String getIndexPage() {
		return "index";
	}
	/*@RequestMapping("/addProduct")
	public String getAddProductPage(@Valid @ModelAttribute("product")ProductBean product,BindingResult result) {
		
		return "addProduct";
	}*/
	@PostMapping("/addProduct")
	public String showPilotDetails(
			@Valid @ModelAttribute("product") ProductBean product,
			BindingResult result) {
		if(!result.hasErrors()) {
			
			final String uri="http://localhost:8083/api/products";
			RestTemplate restTemplate=new RestTemplate();
			
		//	ResponseEntity<Pilot> pilot1=
					restTemplate.postForEntity(uri,product,ProductBean.class);
		
		}
		
		return "redirect:addProduct";
	}
	@RequestMapping("/listproduct")
	public String getProducts(ModelMap map) {
		String url="http://localhost:8083/api/products";
		RestTemplate restTemplate=new RestTemplate();
		ProductBean[] products=restTemplate.getForObject(url, ProductBean[].class);
		map.put("product", new ProductBean());
		map.put("products",products);
		return "listproduct";
	}
	@DeleteMapping("/delete/{productId}")
	public String deletePilot(@PathVariable("productId") Integer productId) {
		
		final String uri="http://localhost:8083/api/products/"+productId;
		RestTemplate restTemplate=new RestTemplate();
		
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("productId", productId);
		
		
		restTemplate.delete(uri,params);
		
		return "index";
	}	
	
}
